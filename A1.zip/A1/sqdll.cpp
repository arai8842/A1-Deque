#include "sqdll.h"

void enqueueFront(node *&head, node *&tail, int value)
{
    // Create the node to be inserted at the front
    node *newNode = new node;
    newNode->data = value;
    newNode->next = head;     // newNode points to first element in the list
    newNode->prev = nullptr;  // no prior elements befor newNode

    // If the deque is emtpty, then newNode also becomes both the head and the tail
    if (head == nullptr){
        head = tail = newNode;
    }
    else { // If not empty, just make newNode the head
        head->prev = newNode;
        head = newNode;
    }

}

// Inserting at the back
void enqueueBack(node *&head, node *&tail, int value)
{
    node *newNode = new node;
    newNode->data = value;
    newNode->next = nullptr;
    newNode->prev = tail;

    if(tail == nullptr)  // if the deque is empty
    {
        head = tail = newNode;
    }
    else
    {
        tail->next = newNode;
        tail = newNode;
    }



}

// Removing from the front
void dequeueFront(node *&head, node *&tail)
{
    if (head == nullptr)
    {
        cout << "Deque is empty, nothing to dequeu from front" << endl;
        return;
    }

    node *temp = head;
    cout << "Dequeued from front: " << temp->data << endl;
    head = head->next;

    if ( head == nullptr) // If deque becomes empty
    {
        tail = nullptr;
    }
    else
    {
        head->prev = nullptr;
    }

    delete temp;

}

// Removing from the back
void dequeueBack(node *&head, node *&tail)
{
    if ( tail == nullptr)
    {
        cout << "Deque is empty, nothing to dequeue from back" << endl;
        return;
        
    }
    
    node *temp = tail;
    cout << " dequeued from back: " << temp->data << endl;
    tail = tail->prev;

    if ( tail == nullptr) // if deque becomes empty
    {
        head = nullptr;

    }
    else 
    {
        tail->next = nullptr;
    }

    delete temp;

}

// Displaying the deque
void displayList(node *head)
{
    node *walker = head;

    while(walker != nullptr)
    {
        cout << walker->data << " ";
        walker = walker -> next;
    }
    cout << endl;
}
