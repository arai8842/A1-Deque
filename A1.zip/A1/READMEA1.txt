2/13/2025
Assignment 1 - stacks and queues
course: CSC300
Ashish Rai

// This project implements a double-ended queue (deque) using a doubly linked list. Include functions to enqueue and dequeue elements from both ends. 

// file includes
// sqdll.h sqdll.cpp maindll.cpp
// sqll.h sqll.cpp mainll.cpp