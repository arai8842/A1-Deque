#include "sqll.h"

// inserting at the begining of the linked list
void push(node *&head, int value)
{
    node *newNode = new node;
    newNode->data = value;
    newNode->next = nullptr;

    // INSERT AT INDEX 0
    newNode->next = head;
    head = newNode;
}

void pop(node *&head)
{
    if(head == nullptr){
        cout << "Stack is empty, nothing to pop" << endl;
        return;
    }

    // removing the head of the linked list
    node *dltTemp = head;
    head = head->next;

    delete dltTemp; // freeing the memory

}

void enqueue(node *&head, int value) 
{
    node *newNode = new node;
    newNode->data = value;
    newNode->next = nullptr;

    if (head == nullptr) // if the queue is empty
    {
        head = newNode;
    }
    else
    {
        node *temp = head;
        while (temp->next != nullptr) // Traverse to the last node
        {
            temp = temp->next;
        }
        temp->next = newNode;
    }

}

void dequeue(node *&head) 
{
    if (head == nullptr)
    {
        cout << "Queue is empty, nothing to dequeue" << endl;
        return;
    }

    node *temp = head;
    head = head->next; // Move head to the next node
    cout << "Dequeued: " << temp->data << endl;
    delete temp;

}

void displayList(node *head)
{
    node *walker = head;

    while(walker != nullptr){
        cout << walker->data << " ";
        walker = walker->next;
    }
    cout << endl;
}